package com.amsoft.ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		boolean casado= true;
	     final int MAXIMO= 999999;
	     byte diasem=1;
	     short diaanual=300;
	     char sexo='M';
	     long milisec=1298332800000L;
	     double totalfactura=10350.678;
	     long poblacion=6775235741L;
	 
	     
	     //printf
	     System.out.printf ("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS -----\n");
	     System.out.printf ("\t El valor de la variable casado es %b\n",casado);
	     System.out.printf ("\t El valor de la variable MAXIMO es %d\n",MAXIMO);
	     System.out.printf ("\t El valor de la variable diasem es %d\n",diasem);
	     System.out.printf ("\t El valor de la variable diaanual es %d\n",diaanual);
	     System.out.printf ("\t El valor de la variable milisec es %d\n",milisec);
	     System.out.printf ("\t El valor de la variable totalfactura es %.6f\n ",totalfactura);
	     System.out.printf ("\t El valor de la variable totalfactura en notación científica es %.6E\n ",totalfactura);
	     System.out.printf ("\t El valor de la variable poblacion es %d\n",poblacion);
	     System.out.printf ("\t El valor de la variable sexo es %c\n",sexo);


	}

}
