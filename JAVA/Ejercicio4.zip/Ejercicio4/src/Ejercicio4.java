
public class Ejercicio4 {

	public static void main(String[] args) {
		SmartPhone miTelefono= new SmartPhone("Apple Iphone 12","IOS 16",6.1,256);
		SmartWatch miReloj = new SmartWatch("Samsung smartwatch","Android",true,true);
		System.out.println(miTelefono.toString());
		System.out.println(miReloj.toString());

	}

}
