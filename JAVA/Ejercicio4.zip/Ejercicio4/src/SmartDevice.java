
public abstract class SmartDevice {

	String marca="";
	String sistemaOperativo="";
	
	
	public SmartDevice(String marca, String so) {
		this.marca=marca;
		this.sistemaOperativo=so;
	}
	
	
	
}
