//factorial de un número

let numero=5;
let factorial=1;

	for (i=numero; i>=1; i--) {
		factorial = factorial * i; 
        
	}
    console.log("El factorial de 5 es: " +factorial);
	 
