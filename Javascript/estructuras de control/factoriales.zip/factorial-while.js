//factorial de un número

let numero=5;
let factorial=1;
let contador=1;
while (numero>=1){
    factorial= factorial * numero;
    numero--;
}
console.log("El factorial de 5 es: " +factorial);
