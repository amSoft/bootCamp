let alturaCentimetros=175;
let alturaMetros=1.74;
let peso=78.10;
let alturaRedondeadaArriba=Math.ceil(alturaMetros);
let pesoRedondeadoAbajo=Math.floor(peso);
let isMaximoValor=Number.MAX_VALUE+1==Number.MAX_VALUE;
