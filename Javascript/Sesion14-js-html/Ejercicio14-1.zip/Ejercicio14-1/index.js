const boton = document.getElementById("btn");
/*
boton.addEventListener("click",()=>{
    alert("click en el botón ");
})
*/
$("#btn").click(()=>{
    alert("Hola estoy utilizando JQuery");
});