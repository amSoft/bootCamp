let nombre="Aurelio";
let apellido="Magdaleno";
let estudiante = nombre.concat(" ",apellido);
let estudianteMayus=estudiante.toUpperCase();
let numeroLetras=estudiante.length;
let primerCaracter=estudiante.charAt(0);
let ultimoCaracter=estudiante.charAt(estudiante.length-1);
let estudianteSinEspacios=estudiante.replace(/ /g,"");
let isNombre=estudiante.includes(nombre);

