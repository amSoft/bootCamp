const logger = require ('./logger');

try {
error; //variable sin definir
}catch (err){
  logger.error("se ha producido un error "+ err)
};


