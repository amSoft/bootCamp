
const familia= new Set(["Juan","Pedro","Alberto","Sofia","Aure"]);

familia.add("Aure");
familia.add("Javascript");
console.log(familia);
