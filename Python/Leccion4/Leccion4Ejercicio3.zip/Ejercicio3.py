for numero in range(100,0,-1):
    print(numero)
    
