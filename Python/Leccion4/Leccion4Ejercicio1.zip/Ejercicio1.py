edad=int(input("Introduce tu edad:"))
if edad>=18:
    print("Eres mayor de edad")
else:
    print("Eres menor de edad")
