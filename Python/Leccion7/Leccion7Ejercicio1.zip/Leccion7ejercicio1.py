import operaciones
print ("La suma de 10+5=",operaciones.sumar(10,5))
print ("La resta de 10-5=",operaciones.restar(10,5))
print ("La multiplicación de 10*5=",operaciones.multiplicar(10,5))
print ("La división de 10/5==",operaciones.dividir(10,5))
