public class Ejercicio1 {

        public static void main(String[ ] args) {
            int resultado=sumaNumeros(100,50,25);
            System.out.println(resultado);
        }
        public  static int sumaNumeros(int a, int b, int c){
            return a+b+c;
        }
    
}
